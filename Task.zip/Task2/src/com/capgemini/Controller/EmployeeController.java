package com.capgemini.Controller;

import java.util.List;

import com.capgemini.Service.EmployeeSevice;
import com.capgemini.entity.Employeee;

public class EmployeeController {
	private EmployeeSevice es= new EmployeeSevice();

	public String insertData(Employeee employee) {
		return es.insertData(employee);
		
	}

	public List<Employeee> GreaterThanSalary(long salary) {
		// TODO Auto-generated method stub
		return es.GreaterThanSalary(salary);
		
	}

	public List<String> NameandExperince(int age) {
		// TODO Auto-generated method stub
		return es.NameandExperince(age);
	}

	public List<Employeee> Name(String profile) {
		// TODO Auto-generated method stub
		return es.Name(profile);
	}

	public List<Employeee> GreaterEqualSalary(long salary) {
		// TODO Auto-generated method stub
		return es.GreaterEqualSalary(salary);
	}

	public void updateSalary(int experience) {
		// TODO Auto-generated method stub
		es.updateSalary(experience);
		
	}
}


