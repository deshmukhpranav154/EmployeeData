package com.capgemini.Dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.capgemini.Configration.HibernateConfigration;
import com.capgemini.entity.Employeee;

public class EmployeeDao {
    SessionFactory factory = HibernateConfigration.getfactory();

	public   boolean insertData(Employeee employee) {
    Session session = factory.openSession();
	session.save(employee);
	session.beginTransaction().commit();
	return true;
	
	}

	public List<Employeee> GreaterThanSalary(long salary) {
	    Session session = factory.openSession();
	    Criteria criteria = session.createCriteria(Employeee.class);
		criteria.add(Restrictions.gt("Salary", salary));
	    List<Employeee> list = criteria.list();
		return list;
	}

	public List<String> NameandExperince(int age) {
		Session session = factory.openSession();
	    Criteria criteria = session.createCriteria(Employeee.class);
		criteria.add(Restrictions.gt("Age", age));
	    criteria.setProjection(Projections.property("Name"));

	    List<String> list = criteria.list();
		return list;
	}

	public List<Employeee> Name(String profile) {
		// TODO Auto-generated method stub
		Session session = factory.openSession();
	    Criteria criteria = session.createCriteria(Employeee.class);
		criteria.add(Restrictions.eq("profile", profile));
	    List<Employeee> list = criteria.list();
		return list;
	}

	public List<Employeee> GreaterEqualSalary(long salary) {
		// TODO Auto-generated method stub
	    Session session = factory.openSession();
	    Criteria criteria = session.createCriteria(Employeee.class);
		criteria.add(Restrictions.ge("Salary", salary));
	    List<Employeee> list = criteria.list();
		return list;
	}

	public void updateSalary(int experience) {
		Session session = factory.openSession();
	    Criteria criteria = session.createCriteria(Employeee.class);
		criteria.add(Restrictions.lt("experience", experience));
		List<Employeee> list = criteria.list();
		for (Employeee employeee : list) {
			employeee.setSalary(employeee.getSalary() + 10000);
			session.update(employeee);
			
		}session.beginTransaction().commit();
		
		
	}

}
