package com.capgemini.Frontend;

import java.util.List;

import com.capgemini.Controller.EmployeeController;
import com.capgemini.entity.Employeee;

public class User {
   public static void main(String[] args) {
/*	Employeee employee =new Employeee();
	employee.setName("john");
	employee.setProfile("dev");
	employee.setEmail("john@gmail.com");
	employee.setSalary(51000);
	employee.setAge(39);
	employee.setExperience(27);
	*/
	 long Salary =10000;
	 int Age= 35;
	 String Profile = "dev";
	  int experience=20;
	EmployeeController ec =new EmployeeController();
	//String msg =ec.insertData(employee);
    //System.out.println(msg);
	/*List<Employeee> list= ec.GreaterThanSalary(Salary);
	for (Employeee employee : list) {
		System.out.println(employee);
	}*/
	/*List<String> list= ec.NameandExperince(Age);
	for (String employee : list) {
		System.out.println(employee);
	}*/
	/*List<Employeee> list= ec.Name(Profile);
	for (Employeee employee : list) {
		System.out.println(employee);
	}*/
	/*List<Employeee> list= ec.GreaterEqualSalary(Salary);
	for (Employeee employee : list) {
		System.out.println(employee);
	}*/
     ec.updateSalary(experience);
     System.out.println("salaryupdated");
}
}
