package com.capgemini.Service;

import java.util.List;

import com.capgemini.Dao.EmployeeDao;
import com.capgemini.entity.Employeee;

public class EmployeeSevice {
	private EmployeeDao ed = new EmployeeDao();
	public String insertData(Employeee employee) {
	
		boolean check=ed.insertData(employee);
		if (check) {
	    	return"book is inserted";
			
		}else {
			return "book is not inserted";
		}
	}

	public List<Employeee> GreaterThanSalary(long salary) {
		// TODO Auto-generated method stub
		return ed.GreaterThanSalary(salary);
		
	}

	public List<String> NameandExperince(int age) {
		return ed.NameandExperince(age);
	}

	public List<Employeee> Name(String profile) {
		// TODO Auto-generated method stub
		return ed.Name(profile);
	}

	public List<Employeee> GreaterEqualSalary(long salary) {
		// TODO Auto-generated method stub
		return ed.GreaterEqualSalary(salary);
	}

	public void updateSalary(int experience) {
		// TODO Auto-generated method stub
		ed.updateSalary(experience);

	}

}
