package com.capgemini.Configration;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.capgemini.entity.Employeee;


public class HibernateConfigration {
	 public static final SessionFactory getfactory(){
		    Configuration cfg = new Configuration();
		    cfg.configure();
		    cfg.addAnnotatedClass(Employeee.class);
		    SessionFactory factory =cfg.buildSessionFactory();
		    return factory;
}}
